# Urdu Caption Studio — Android starter project

This is an Android Studio source project for an Urdu / Roman Urdu subtitle editor.

## Included in this starter
- Android app built with Kotlin + Jetpack Compose
- Video picker (MP4/MOV/etc. supported by Android document picker)
- Editable caption text and start/end timestamps
- Caption strip/timeline selection
- Basic style controls and preview mock-up
- Add/delete caption controls
- SRT subtitle export

## Not yet connected (important)
This is a starter implementation, not a finished CapCut replacement or installable APK.
The following production modules still need implementation and device testing:
1. Offline Urdu speech recognition (Whisper.cpp JNI or another compatible on-device ASR engine)
2. Urdu-to-Roman-Urdu transliteration
3. Real video preview/player
4. Caption overlay renderer and 1080p MP4 export
5. Real font file loading, outline/shadow/background rendering, and animation rendering
6. Project persistence and long-video memory/performance management

The UI labels these limitations instead of pretending those engines are already working.

## Open in Android Studio
1. Install Android Studio with JDK 17.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Run on an Android 8.0+ device or emulator.

## Next engineering milestones
- Add a JNI module wrapping whisper.cpp and provide a downloadable multilingual Whisper model.
- Extract audio with Android MediaExtractor and feed 16 kHz mono PCM to ASR.
- Convert word/segment timestamps into Caption objects.
- Use MediaCodec + MediaMuxer (or a maintained media rendering library) to render 1080p H.264 MP4 with caption overlays.
- Bundle licensed Urdu Nastaliq and Latin fonts, with user-imported font support.
- Add preview seek synchronization and persistent project storage.

## Free/offline notes
The editor UI itself does not require an API key. Fully offline automatic transcription requires downloading a compatible model first; model size, speed, RAM use, and Urdu accuracy depend on the selected model and phone hardware. 1080p rendering also depends on device encoder support and available storage.
