# Engine integration contract

## ASR
Input: 16 kHz, mono, signed 16-bit PCM audio.
Output: ordered segments containing startMs, endMs, recognized Urdu text.
Do not assume the Android SpeechRecognizer is offline or supports Urdu offline.

## Roman Urdu
Keep original Urdu transcript unchanged. Transliteration must be a separate editable output because proper nouns, code-switching, and regional pronunciation can produce ambiguous Roman spellings.

## Video export
Render source video at original aspect ratio, with a 1080p maximum output profile:
- Portrait: 1080x1920
- Landscape: 1920x1080
- Square: 1080x1080
Use MediaCodec/MediaMuxer or a maintained media renderer. Keep captions in a separate timed layer until export.
