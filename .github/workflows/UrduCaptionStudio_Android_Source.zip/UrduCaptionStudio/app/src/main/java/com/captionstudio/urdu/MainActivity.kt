package com.captionstudio.urdu

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Caption(
    val id: Int,
    val startMs: Long,
    val endMs: Long,
    val text: String
)

enum class CaptionLanguage { URDU, ROMAN }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CaptionStudioApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CaptionStudioApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("No video selected") }
    var language by remember { mutableStateOf(CaptionLanguage.URDU) }
    var selectedIndex by remember { mutableIntStateOf(0) }
    var nextId by remember { mutableIntStateOf(3) }
    var fontSize by remember { mutableFloatStateOf(28f) }
    var outline by remember { mutableStateOf(true) }
    var bold by remember { mutableStateOf(true) }
    var textColor by remember { mutableStateOf("White") }
    var animation by remember { mutableStateOf("Pop") }
    var status by remember { mutableStateOf("Import a video to begin. You can also add captions manually.") }
    var captions by remember {
        mutableStateOf(
            listOf(
                Caption(1, 0, 2200, "السلام علیکم، آپ کیسے ہیں؟"),
                Caption(2, 2200, 4600, "Assalam o Alaikum, aap kaise hain?")
            )
        )
    }
    var editingText by remember { mutableStateOf("") }
    var editingStart by remember { mutableStateOf("0.0") }
    var editingEnd by remember { mutableStateOf("2.2") }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            videoUri = uri
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            videoName = DocumentFile.fromSingleUri(context, uri)?.name ?: "Selected video"
            status = "Video imported. Speech-to-text engine integration is required for automatic transcription."
        }
    }

    val srtSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri ->
        if (uri != null) {
            val srt = captions.sortedBy { it.startMs }.mapIndexed { index, c ->
                "${index + 1}\n${toSrtTime(c.startMs)} --> ${toSrtTime(c.endMs)}\n${c.text}\n"
            }.joinToString("\n")
            context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(srt) }
            status = "SRT subtitle file saved."
        }
    }

    LaunchedEffect(selectedIndex, captions) {
        val c = captions.getOrNull(selectedIndex)
        if (c != null) {
            editingText = c.text
            editingStart = "%.1f".format(Locale.US, c.startMs / 1000f)
            editingEnd = "%.1f".format(Locale.US, c.endMs / 1000f)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFB7A2FF),
            secondary = Color(0xFF63D8C5),
            background = Color(0xFF101018),
            surface = Color(0xFF1B1B28)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Urdu Caption Studio", fontWeight = FontWeight.Bold)
                            Text("Video subtitles • Urdu + Roman Urdu", fontSize = 11.sp, color = Color.LightGray)
                        }
                    },
                    actions = {
                        IconButton(onClick = { srtSaver.launch("captions.srt") }) {
                            Icon(Icons.Default.Save, contentDescription = "Export SRT")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF171725))
                )
            },
            containerColor = Color(0xFF101018)
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF211D38))) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Movie, contentDescription = null, tint = Color(0xFFB7A2FF))
                                Spacer(Modifier.width(8.dp))
                                Text("VIDEO PROJECT", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Text(videoName, color = Color(0xFFE5E1F5))
                            Button(onClick = { videoPicker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Choose video")
                            }
                            Text("Preview/export rendering and automatic ASR are planned engine modules; this starter currently edits captions and exports SRT.", fontSize = 11.sp, color = Color(0xFFC8C2D9))
                        }
                    }
                }

                item {
                    SectionTitle("CAPTION LANGUAGE")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = language == CaptionLanguage.URDU, onClick = { language = CaptionLanguage.URDU }, label = { Text("اردو") })
                        FilterChip(selected = language == CaptionLanguage.ROMAN, onClick = { language = CaptionLanguage.ROMAN }, label = { Text("Roman Urdu") })
                    }
                }

                item {
                    SectionTitle("CAPTION PREVIEW")
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF292938))) {
                        Box(
                            Modifier.fillMaxWidth().height(180.dp).padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            val preview = captions.getOrNull(selectedIndex)?.text ?: "Your caption preview"
                            Text(
                                preview,
                                color = if (textColor == "Yellow") Color.Yellow else Color.White,
                                fontSize = fontSize.sp,
                                fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
                                textAlign = TextAlign.Center,
                                fontFamily = if (language == CaptionLanguage.URDU) FontFamily.SansSerif else FontFamily.Default,
                                modifier = Modifier
                                    .background(Color(0x99000000), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                    Text("Preview is a style mock-up; actual font rendering is applied in the video renderer module.", fontSize = 10.sp, color = Color.Gray)
                }

                item {
                    SectionTitle("CAPTION TIMELINE")
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        captions.forEachIndexed { index, caption ->
                            Card(
                                modifier = Modifier.width(150.dp).clickable { selectedIndex = index },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selectedIndex == index) Color(0xFF493A79) else Color(0xFF242432)
                                )
                            ) {
                                Column(Modifier.padding(10.dp)) {
                                    Text("Caption ${index + 1}", fontWeight = FontWeight.Bold, color = Color.White)
                                    Text("${caption.startMs / 1000f}s – ${caption.endMs / 1000f}s", fontSize = 11.sp, color = Color.LightGray)
                                    Text(caption.text, maxLines = 2, color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            val id = nextId++
                            captions = captions + Caption(id, 0, 2000, "New caption")
                            selectedIndex = captions.lastIndex
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Add caption")
                    }
                }

                item {
                    SectionTitle("EDIT SELECTED CAPTION")
                    OutlinedTextField(
                        value = editingText,
                        onValueChange = { editingText = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Caption text") },
                        minLines = 2
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editingStart,
                            onValueChange = { editingStart = it },
                            modifier = Modifier.weight(1f),
                            label = { Text("Start (sec)") }
                        )
                        OutlinedTextField(
                            value = editingEnd,
                            onValueChange = { editingEnd = it },
                            modifier = Modifier.weight(1f),
                            label = { Text("End (sec)") }
                        )
                    }
                    Button(
                        onClick = {
                            val old = captions.getOrNull(selectedIndex)
                            if (old != null) {
                                val start = ((editingStart.toFloatOrNull() ?: 0f) * 1000).toLong().coerceAtLeast(0)
                                val end = ((editingEnd.toFloatOrNull() ?: 2f) * 1000).toLong().coerceAtLeast(start + 100)
                                captions = captions.toMutableList().also {
                                    it[selectedIndex] = old.copy(startMs = start, endMs = end, text = editingText)
                                }
                                status = "Caption updated."
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Apply caption changes") }
                    OutlinedButton(
                        onClick = {
                            if (captions.isNotEmpty() && selectedIndex in captions.indices) {
                                captions = captions.toMutableList().also { it.removeAt(selectedIndex) }
                                selectedIndex = (selectedIndex - 1).coerceAtLeast(0)
                                status = "Caption deleted."
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Delete selected caption")
                    }
                }

                item {
                    SectionTitle("FONT & STYLE")
                    Text("Font size: ${fontSize.toInt()} sp")
                    Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 16f..52f)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Bold", modifier = Modifier.weight(1f))
                        Switch(checked = bold, onCheckedChange = { bold = it })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Outline (preview setting)", modifier = Modifier.weight(1f))
                        Switch(checked = outline, onCheckedChange = { outline = it })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = textColor == "White", onClick = { textColor = "White" }, label = { Text("White") })
                        FilterChip(selected = textColor == "Yellow", onClick = { textColor = "Yellow" }, label = { Text("Yellow") })
                    }
                    SectionTitle("ANIMATION PRESET")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("None", "Fade", "Pop", "Bounce", "Typewriter", "Karaoke").forEach {
                            FilterChip(selected = animation == it, onClick = { animation = it }, label = { Text(it) })
                        }
                    }
                    Text("Selected: $animation • Export animation renderer is not connected in this starter.", fontSize = 11.sp, color = Color.Gray)
                }

                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202A2A))) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("PROJECT STATUS", fontWeight = FontWeight.Bold, color = Color.White)
                            Text(status, color = Color(0xFFD4E8E2), fontSize = 12.sp)
                            Button(onClick = { srtSaver.launch("urdu-captions.srt") }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Save, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Export subtitles (.SRT)")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, fontWeight = FontWeight.Bold, color = Color(0xFFB7A2FF), fontSize = 13.sp)
    Spacer(Modifier.height(5.dp))
}

fun toSrtTime(ms: Long): String {
    val safe = ms.coerceAtLeast(0)
    val hours = safe / 3_600_000
    val minutes = (safe % 3_600_000) / 60_000
    val seconds = (safe % 60_000) / 1_000
    val millis = safe % 1_000
    return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
}
